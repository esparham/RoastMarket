<template>
  <ul class="productList">
    <slot></slot>
  </ul>
</template>

<script>
export default {
  name: 'CardWrapper',
}
</script>